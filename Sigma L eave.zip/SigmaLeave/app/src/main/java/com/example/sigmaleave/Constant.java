package com.example.sigmaleave;

public class Constant {
    public static final String Running_EMP_ID= "Running_EMP_ID";
    public static final String Current_EMP_ID= "Current_EMP_ID";
    public static final String Running_M_ID= "Running_M_ID";
    public static final String Current_M_ID= "Current_M_ID";
    public static final String USER_TYPE= "UserType";
}
