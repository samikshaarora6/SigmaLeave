package com.example.sigmaleave;

public interface OnItemClickListener {
    void onItemClick(int id, int position,boolean status);
}
