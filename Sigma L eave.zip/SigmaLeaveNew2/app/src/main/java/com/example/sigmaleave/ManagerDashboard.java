package com.example.sigmaleave;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ManagerDashboard extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manager_dashboard);
    }
}
